package tema5.prueba;

public interface Correr {
    void correr ();
}
