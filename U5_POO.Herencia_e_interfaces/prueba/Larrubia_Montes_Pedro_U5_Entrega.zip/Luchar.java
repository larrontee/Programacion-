package tema5.prueba;

public interface Luchar {
    void lucahr();
}
