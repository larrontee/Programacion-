package tema5.prueba;

public interface Encestar {
    void encestar();
}
