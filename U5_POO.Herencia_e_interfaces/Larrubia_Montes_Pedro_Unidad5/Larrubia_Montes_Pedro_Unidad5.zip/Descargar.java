package com.company;

public interface Descargar {
    void descargar();
}
