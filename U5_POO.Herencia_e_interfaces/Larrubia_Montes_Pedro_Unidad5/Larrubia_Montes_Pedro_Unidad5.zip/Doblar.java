package com.company;

public interface Doblar {
    void doblar();
}
