public enum Categoria {
    SENIOR, JUNIOR, VETERANO
}
