public enum MetodoPago {
    TARJETA_DE_CREDITO, PAYPAL, STRIPE
}
