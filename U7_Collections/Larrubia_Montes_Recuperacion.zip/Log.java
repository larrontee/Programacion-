public interface Log {
     void printLog();
}
