package ej1;

public enum TipoInterfaz {
    BLUETOOH, IR, JACK
}
