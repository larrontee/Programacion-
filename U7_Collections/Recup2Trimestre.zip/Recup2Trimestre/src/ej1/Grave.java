package ej1;

public interface Grave {
}
