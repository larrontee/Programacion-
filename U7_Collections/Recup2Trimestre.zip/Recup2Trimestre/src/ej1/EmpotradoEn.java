package ej1;

public enum EmpotradoEn {
    PUERTA, SALPICADERO
}
