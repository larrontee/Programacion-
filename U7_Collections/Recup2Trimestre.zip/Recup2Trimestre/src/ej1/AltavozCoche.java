package ej1;

public abstract class AltavozCoche extends Altavoz{
    public AltavozCoche(int numSerie, int ancho, int alto) {
        super(numSerie, ancho, alto);
    }

}
